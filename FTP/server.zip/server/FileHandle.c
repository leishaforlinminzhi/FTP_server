#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>     /* defines STDIN_FILENO, system calls,etc */
#include <sys/types.h>  /* system data type definitions */
#include <sys/socket.h> /* socket specific definitions */
#include <netinet/in.h> /* INET constants and stuff */
#include <arpa/inet.h>  /* IP address conversion stuff */
#include <netdb.h>      /* gethostbyname */
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#include"StructofServer.h"
#include"FileHandle.h"

char file_path[MAXBUF];

char* get_file_path(const char*msg){
    char* format = "%*s %s";
    char* file_path;
    sscanf(msg, format, file_path);
    return strdup(file_path);
}

int handle_retr(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    FILE* file;
    int len;
    char line[MAXBUF];
    int bytes_read;
    if (info->state_flag == 2) {
        strcpy(file_path, msg + 5);
        len = strlen(file_path);
        while (len > 0 && (file_path[len - 1] == '\r' || file_path[len - 1] == '\n'))
             file_path[--len] = 0;  
        
        if (info->binary_flag)
            file = fopen(file_path, "rb");
        else
            file = fopen(file_path, "r");

        if (file == NULL) {
            strcpy(info->buf, "550 File not found.\r\n");
            return 1;
        }

        while ((bytes_read = fread(line, 1, sizeof(line), file)) > 0) {
            strcat(info->buf, line);
        }
        fclose(file);
        if (info->buf[strlen(info->buf) - 1] != '\n')
            strcat(info->buf, "\r\n");
        strcat(info->buf, "226 Transfer complete.\r\n");
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
    }

}

int handle_mkd(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    strcpy(file_path, msg + 4);
    //printf("%s\n",get_file_path(msg));
    if (info->state_flag == 2) {
        if (strlen(msg) < 4) {
            strcpy(info->buf, "501 Please enter the path.\r\n");
            return 1;
        }
        if(chdir(info->WorkingPlace) != 0){
            strcpy(info->buf, "550 Current path not found.\r\n");
            return 1;
        }
        if(mkdir(file_path, S_IRWXU | S_IRWXG | S_IRWXO)!=0){
            chmod(file_path, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH |S_IWOTH);
            strcpy(info->buf, "550 Fail to create the file.\r\n");
            return 1;
        }
        strcpy(info->buf, "250 Successfully created the file.\r\n");
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_cwd(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    strcpy(file_path, msg + 4);
    if (info->state_flag == 2) {
        if (strlen(msg) < 4) {
            strcpy(info->buf, "501 Please enter the path.\r\n");
            return 1;
        }
        if(chdir(file_path) != 0){
            sprintf(info->buf, "550 %s: No such file or directory.\r\n", file_path);
            return 1;
        }else{
            strcpy(info->WorkingPlace, file_path);
            strcpy(info->buf, "250 Okay.\r\n");
        }
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_pwd(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    char current_dir[MAXBUF];
    if (info->state_flag == 2) {
        if (strlen(msg) > 4) {
            strcpy(info->buf, "501 Invalid input parameters\r\n");
            return 1;
        }
        if (info->WorkingPlace != NULL) 
            sprintf(info->buf, "257 \"%s\" \r\n", info->WorkingPlace);
        else {
            strcpy(info->buf, "550 Failed to get current directory.\r\n");
            return 1;
        }
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_list(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    char command[MAXBUF]="ls -l";
    char line[MAXBUF];
    FILE *file;

    if (info->state_flag == 2) {
        if(chdir(info->WorkingPlace) != 0){
            strcpy(info->buf, "451 Current path not found.\r\n");
            return 1;
        }
        strcpy(file_path, msg + 5);
        if(file_path != NULL)
            strcat(command, file_path);
        if((file = popen(command, "r") == NULL)){
            strcpy(info->buf, "451 Fail to execute the command: popen error.\r\n");
            return 1;
        }
        while(fread(line, 1, sizeof(line), file) > 0){
            strcat(info->buf, line);
        }

        pclose(file);

        if (info->buf[strlen(info->buf) - 1] != '\n')
            strcat(info->buf, "\r\n");
        strcat(info->buf, "226 Transfer complete.\r\n");
        
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_rmd(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    char command[MAXBUF]="ls -l";
    char line[MAXBUF];
    FILE *file;

    if (info->state_flag == 2) {
        if(chdir(info->WorkingPlace) != 0){
            strcpy(info->buf, "451 Current path not found.\r\n");
            return 1;
        }
        strcpy(file_path, msg + 5);
        if(file_path != NULL)
            strcat(command, file_path);
        if((file = popen(command, "r") == NULL)){
            strcpy(info->buf, "451 Fail to execute the command: popen error.\r\n");
            return 1;
        }
        while(fread(line, 1, sizeof(line), file) > 0){
            strcat(info->buf, line);
        }

        pclose(file);

        if (info->buf[strlen(info->buf) - 1] != '\n')
            strcat(info->buf, "\r\n");
        strcat(info->buf, "226 The directory was successfully removed.\r\n");
        
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

