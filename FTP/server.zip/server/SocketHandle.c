#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>     /* defines STDIN_FILENO, system calls,etc */
#include <sys/types.h>  /* system data type definitions */
#include <sys/socket.h> /* socket specific definitions */
#include <netinet/in.h> /* INET constants and stuff */
#include <arpa/inet.h>  /* IP address conversion stuff */
#include <netdb.h>      /* gethostbyname */
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#include"StructofServer.h"
#include"SocketHandle.h"


int handle_post(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    if(info->state_flag == 2){
        int ip[4]; 
        int port[2];
        const char* format = "%*s %d,%d,%d,%d,%d,%d";
        int count = sscanf(msg, format, &ip[0], &ip[1], &ip[2], &ip[3], &port[0], &port[1]);

        if(info->data_fd < 0){
            close(info->data_fd);
        }

        info->data_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (info->data_fd < 0) {
           perror("Error opening data socket");
           exit(1);
        }

        memset(&info->data_addr, 0, sizeof(info->data_addr));
        info->data_addr.sin_family = AF_INET;
        info->data_addr.sin_addr.s_addr = inet_addr(ip);
        info->data_addr.sin_port = htons(port[0] * 256 + port[1]);


        strcpy(info->buf, "200 PORT command successful. Data connection established.\r\n");
    }else{
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
    }
    return 0;
}

int handle_pasv(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    if(info->state_flag == 2){
        int port = rand() % 45536 + 20000;
    }else{
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
    }
    return 0;
}

