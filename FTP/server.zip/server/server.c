#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>     /* defines STDIN_FILENO, system calls,etc */
#include <sys/types.h>  /* system data type definitions */
#include <sys/socket.h> /* socket specific definitions */
#include <netinet/in.h> /* INET constants and stuff */
#include <arpa/inet.h>  /* IP address conversion stuff */
#include <netdb.h>      /* gethostbyname */
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#include"RequestHandle.h"
#include"StructofServer.h"

#define MAXBUF 1024


int main() {
    struct sockaddr_in skaddr;
    socklen_t length;

    struct Serverinfo info;
    server_init(&info);


    if ((info.listen_fd = socket(PF_INET, SOCK_DGRAM, 0)) < 0) {
        printf("s Problem creating socket\n");
        exit(1);
    }

    skaddr.sin_family = AF_INET;
    skaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    skaddr.sin_port = htons(10001);

    if (bind(info.listen_fd, (struct sockaddr*)&skaddr, sizeof(skaddr)) < 0) {
        printf("s Problem binding\n");
        exit(1);
    }

    /* find out what port we were assigned and print it out */
    length = sizeof(skaddr);
    if (getsockname(info.listen_fd, (struct sockaddr*)&skaddr, &length) < 0) {
        printf("s Error getsockname\n");
        exit(1);
    }


    char bufin[MAXBUF];
    struct sockaddr_in remote;
    socklen_t len = sizeof(remote);

    int exec_state;
    char buf[MAXBUF];
    size_t buf_len;
    
    
    while (1) { 
        memset(bufin, 0, sizeof(bufin));
        int client_fd = recvfrom(info.listen_fd, bufin, MAXBUF, 0, (struct sockaddr*)&info.remote, &len);
        if (client_fd < 0) { 
            printf("s fail to receive"); 
            break; 
        }
        if (client_fd == 0) { 
            break;
        }

        printf("s Received command:");
        printf(bufin);

        handle_request(bufin, &info);
        memset(buf, 0, sizeof(buf));

    }


    close(info.listen_fd); 
    return 0;
}
