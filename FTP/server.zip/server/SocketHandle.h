#pragma once
#ifndef SOCKETHANDLE_H
#define SOCKETHANDLE_H

#include"StructofServer.h"

extern int handle_post(const char* msg, struct Serverinfo* info);

//extern bool handle_mkd(const char* msg, Serverinfo* info);

//extern bool handle_list(const char* msg, Serverinfo* info);

extern int handle_pasv(const char* msg, struct Serverinfo* info);


#endif // !PLACEHANDLE_H
