#pragma once
#ifndef STRUCTOFSERVER_H
#define STRUCTOFSERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>     /* defines STDIN_FILENO, system calls,etc */
#include <sys/types.h>  /* system data type definitions */
#include <sys/socket.h> /* socket specific definitions */
#include <netinet/in.h> /* INET constants and stuff */
#include <arpa/inet.h>  /* IP address conversion stuff */
#include <netdb.h>      /* gethostbyname */
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#define MAXBUF 1024

struct Serverinfo {
	struct sockaddr_in remote;

	int state_flag; // login state
	int binary_flag; // binary state

	int DataPort;
	int ConnectType;
	int StartPoint;

	char RootPlace[MAXBUF];	//root
	char WorkingPlace[MAXBUF]; // work
	char CurrentPlace[MAXBUF]; // need to be execute

	int data_fd; // data
	struct sockaddr_in data_addr;

	int listen_fd; //client 
	char buf[MAXBUF]; //buffer send to client
};


extern void server_init(struct Serverinfo* info);

#endif // !STRUCTOFSERVER_H
