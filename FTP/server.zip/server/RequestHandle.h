#pragma once
#ifndef REQUESTHANDLE_H
#define REQUESTHANDLE_H

#include"StructofServer.h"

extern int handle_request(const char* msg, struct Serverinfo* info);


#endif // !REQUESTHANDLE_H

