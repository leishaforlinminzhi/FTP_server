#include"StructofServer.h"

void server_init(struct Serverinfo* info) {
	info->state_flag = 0;
	info->binary_flag = 0;

	info->listen_fd = -1;
	info->data_fd = -1;

	getcwd(info->WorkingPlace, sizeof(info->WorkingPlace));
	strcpy(info->RootPlace, info->WorkingPlace);
	return;
}
