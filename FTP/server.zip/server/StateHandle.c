#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>     /* defines STDIN_FILENO, system calls,etc */
#include <sys/types.h>  /* system data type definitions */
#include <sys/socket.h> /* socket specific definitions */
#include <netinet/in.h> /* INET constants and stuff */
#include <arpa/inet.h>  /* IP address conversion stuff */
#include <netdb.h>      /* gethostbyname */
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#include"StructofServer.h"


int handle_user(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    switch (info->state_flag)
    {
    case 0:
        if (strncmp(msg, "USER anonymous", strlen("USER anonymous")) == 0) { 
            info->state_flag = 1; 
            strcpy(info->buf, "331 Guest login ok, send your complete e-mail address as password.\r\n");
        }
        else {
            strcpy(info->buf, "530 All users other than anonymous are not supported.\r\n");
        }
        break;
    case 1:
        strcpy(info->buf, "530 USER anonymous is logging in, please input the password.\r\n");
        break;
    case 2:
        strcpy(info->buf, "502 USER anonymous already login.\r\n");
        break;
    default:
        break;
    }
    return 0;
}

int handle_pass(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    switch (info->state_flag)
    {
    case 0:
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        break;
    case 1:
        if (strlen(msg) > 6) { 
            info->state_flag = 2; 
            strcpy(info->buf, "230 USER anonymous, welcome!\r\n");
        }
        else
            strcpy(info->buf, "500 Please enter your complete e-mail address as password.\r\n");
        break;
    case 2:
        strcpy(info->buf, "502 USER anonymous already login.\r\n");
        break;
    default:
        break;
    }
    return 0;
}

int handle_type(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    if (info->state_flag == 2) {
        char* type_param;
        strcpy(type_param, msg + 5);
        printf(type_param);
        if (strncmp(type_param, "A", 1) == 0 || strncmp(type_param, "A N", 3) == 0) {
            info->binary_flag = 0;
            strcpy(info->buf, "200 Binary flag is now off\r\n");
        }
        else if (strncmp(type_param, "I", 1) == 0 || strncmp(type_param, "L 8", 3) == 0) {
            info->binary_flag = 1;
            strcpy(info->buf, "200 Binary flag is now on\r\n");
        }
        else {
            strcpy(info->buf, "501 Invalid input parameters\r\n");
        }
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
    }
    return 0;
}

int handle_syst(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    if (info->state_flag == 2) {
        if (info->binary_flag)
            strcpy(info->buf, "216 UNIX Type:A\r\n");
        else
            strcpy(info->buf, "216 UNIX Type:I\r\n");
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
    }
    return 0;
}
