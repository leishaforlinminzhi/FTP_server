#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>     /* defines STDIN_FILENO, system calls,etc */
#include <sys/types.h>  /* system data type definitions */
#include <sys/socket.h> /* socket specific definitions */
#include <netinet/in.h> /* INET constants and stuff */
#include <arpa/inet.h>  /* IP address conversion stuff */
#include <netdb.h>      /* gethostbyname */
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#include"RequestHandle.h"
#include"StructofServer.h"

#define MAXBUF 1024

/*
int state = 0; // ȫ��״̬����, 0 await"USER" 1 await"PASS", 2 for login
int binary_flag = 0; // TYPE����flag
int data_sockfd;
struct sockaddr_in data_addr;


char* handle_user(const char* msg) {
    // ���� USER ����
    if (strncmp(msg, "USER anonymous", strlen("USER anonymous")) == 0) { // ������յ���������USER anonymous
        state = 1; // ��״̬����Ϊ�ȴ�PASSWORD
        return "331 Guest login ok, send your complete e-mail address as password.\r\n";
    }
    else {
        return "530 All users other than anonymous are not supported.\r\n";
    }
}

// TODO: �����û�table
char* handle_pass(const char* msg) {
    // ���� PASS ����
    if (strlen(msg) > 6) { // ������յ���������������
        state = 2; // ��״̬����Ϊlogin
        return "230 USER anonymous, welcome!\r\n";
    }
    else
        return "500 Please enter your complete e-mail address as password.\r\n";
}


char* handle_retr(const char* msg, int ld) {
    char file_path[MAXBUF];
    strcpy(file_path, msg + 5);
    int len = strlen(file_path);
    while (len > 0 && (file_path[len - 1] == '\r' || file_path[len - 1] == '\n')) {
        file_path[--len] = 0;  // �����һ���س������з��滻Ϊ�ַ���������\0
    }
    printf("{%s}", file_path);
    FILE* file;
    if (binary_flag)
        file = fopen(file_path, "rb");
    else
        file = fopen(file_path, "r");
    if (file == NULL) {
        return "550 File not found.\r\n";
    }

    // ��ȡ�ļ����ݲ����͸��ͻ���
    char buffer[MAXBUF];
    memset(buffer, 0, sizeof(buffer));
    char line[MAXBUF];
    int bytes_read;
    while ((bytes_read = fread(line, 1, sizeof(line), file)) > 0) {
        strcat(buffer, line);
    }
    fclose(file);
    if (buffer[strlen(buffer) - 1] != '\n') {
        strcat(buffer, "\r\n");
    }
    strcat(buffer, "226 Transfer complete.\r\n");
    return strdup(buffer);
}

//TODO:displays some statistics about the ftp connection
char* handle_quit(const char* msg) {
    state = 0;
    //displays some statistics about the ftp connection
    return "221 Thank you for using the FTP service\r\n221 Bye\r\n";
}

//TODO��type�����ļ��֣�
char* handle_syst(const char* msg) {
    if (binary_flag)
        return "216 UNIX Type:A";
    else
        return "216 UNIX Type:I";
}

char* handle_type(const char* msg) {
    char* type_param;
    strcpy(type_param, msg + 5);
    printf(type_param);
    if (strncmp(type_param, "A", 1) == 0 || strncmp(type_param, "A N", 3) == 0) {
        binary_flag = 0;
        return "200 Binary flag is now off\r\n";
    }
    else if (strncmp(type_param, "I", 1) == 0 || strncmp(type_param, "L 8", 3) == 0) {
        binary_flag = 1;
        return "200 Binary flag is now on\r\n";
    }
    else {
        return "501 Invalid input parameters\r\n";
    }
}

//TODO�����ɹ���û��
char* handle_port(const char* msg) {
    int ip[4]; // �洢 IP ��ַ
    int port[2]; // �洢�˿���Ϣ
    const char* format = "%*s %d,%d,%d,%d,%d,%d";
    int count = sscanf(msg, format, &ip[0], &ip[1], &ip[2], &ip[3], &port[0], &port[1]);

    printf("%d %d %d %d %d %d", ip[0], ip[1], ip[2], ip[3], port[0], port[1]);

    // ������������

    //data_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    //if (data_sockfd < 0) {
    //    perror("Error opening data socket");
    //    exit(1);
    //}

    //memset(&data_addr, 0, sizeof(data_addr));
    //data_addr.sin_family = AF_INET;
    //data_addr.sin_addr.s_addr = inet_addr(ip);
    //data_addr.sin_port = htons(port[0] * 256 + port[1]);

    //if (connect(data_sockfd, (struct sockaddr*)&data_addr, sizeof(data_addr)) < 0) {
    //    perror("Error connecting to client data port");
    //    exit(1);
    //}

    //// ������Ӧ
    //char response[] = "200 PORT command successful. Data connection established.\n";
    //int bytes_sent = sendto(sockfd, response, sizeof(response), 0, (struct sockaddr*)&client_addr, client_len);
    //if (bytes_sent < 0) {
    //    return "425 The connection attempt fails.\r\n";
    //}

    // ��������Խ����ļ�������������ݴ������

    // �ر����������׽���
    // close(data_sockfd);

    return "200 PORT command successful.\r\n";
}

char* handle_pasv(const char* msg) {

}

char* handle_pwd(const char* msg) {
    char current_dir[MAXBUF];
    char new_dir[MAXBUF];
    memset(current_dir, 0, sizeof(current_dir));
    if (strlen(msg) > 4) {
        return "501 Invalid input parameters\r\n";
    }
    if (getcwd(current_dir, sizeof(current_dir)) != NULL) {
        sprintf(new_dir, "257 \"%s\" \r\n", current_dir);
        printf("dir: %s", new_dir);
        return strdup(new_dir);
    }
    else {
        return "550 Failed to get current directory.\r\n";
    }
}
*/


int main() {
    struct sockaddr_in skaddr;
    socklen_t length;

    struct Serverinfo info;


    if ((info.listen_fd = socket(PF_INET, SOCK_DGRAM, 0)) < 0) {
        printf("s Problem creating socket\n");
        exit(1);
    }

    skaddr.sin_family = AF_INET;
    skaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    skaddr.sin_port = htons(8017);

    if (bind(info.listen_fd, (struct sockaddr*)&skaddr, sizeof(skaddr)) < 0) {
        printf("s Problem binding\n");
        exit(1);
    }

    /* find out what port we were assigned and print it out */
    length = sizeof(skaddr);
    if (getsockname(info.listen_fd, (struct sockaddr*)&skaddr, &length) < 0) {
        printf("s Error getsockname\n");
        exit(1);
    }

    char username[256] = { 0 }; // ����û���
    char password[256] = { 0 }; // �������

    char bufin[MAXBUF];
    struct sockaddr_in remote;
    socklen_t len = sizeof(remote);

    int exec_state;
    char buf[MAXBUF];
    size_t buf_len;

    while (1) { // ѭ���ȴ��ͻ�������
        memset(bufin, 0, sizeof(bufin));
        int client_fd = recvfrom(info.listen_fd, bufin, MAXBUF, 0, (struct sockaddr*)&info.remote, &len);
        if (client_fd < 0) { // �������ʧ��
            printf("s fail to receive"); // ���������Ϣ
            break; // ����ѭ��
        }
        if (client_fd == 0) { // ����ͻ����ѹر�����
            break; // ����ѭ��
        }

        printf("s Received command:");
        printf(bufin);
        printf("\n");

        handle_request(bufin, &info);
        memset(buf, 0, sizeof(buf));
        //if (state == 0) {
        //    // await"USER"״̬
        //    switch (get_cmd_type(bufin))
        //    {
        //    case USER:
        //        strcpy(buf, handle_user(bufin));
        //        break;
        //    case UNKNOWN:
        //        strcpy(buf, "405 Your command is invalid.\r\n");
        //        break;
        //    default:
        //        strcpy(buf, "530 Please input your username and login first.\r\n");
        //        break;
        //    }
        //}
        //else if (state == 1) {
        //    // await"PASS"״̬
        //    switch (get_cmd_type(bufin))
        //    {
        //    case PASS:
        //        strcpy(buf, handle_pass(bufin));
        //        break;
        //    default:
        //        strcpy(buf, "530 Please input your password first.\r\n");
        //        break;
        //    }
        //}
        //else if (state == 2) {
        //    // login״̬
        //    switch (get_cmd_type(bufin))
        //    {
        //    case USER:
        //        strcpy(buf, "502 USER anonymous already login.\r\n");
        //        break;
        //    case PASS:
        //        strcpy(buf, "502 USER anonymous already login.\r\n");
        //        break;
        //    case RETR:
        //        strcpy(buf, handle_retr(bufin, ld));
        //        break;
        //    case STOR:
        //        break;
        //    case QUIT:
        //        strcpy(buf, handle_quit(bufin));
        //        break;
        //    case SYST:
        //        strcpy(buf, handle_syst(bufin));
        //        break;
        //    case TYPE:
        //        strcpy(buf, handle_type(bufin));
        //        break;
        //    case PORT_:
        //        //strcpy(buf, handle_port(bufin));
        //        break;
        //    case PASV:
        //        break;
        //    case MKD:
        //        break;
        //    case CWD:
        //        break;
        //    case PWD:
        //        strcpy(buf, handle_pwd(bufin));
        //        break;
        //    case LIST:
        //        break;
        //    case RMD:
        //        break;
        //    case RNFR:
        //        break;
        //    case RNTO:
        //        break;
        //        // ��������Ĵ�����ʽ���԰��������ĸ�ʽ�������� case ���
        //    default:
        //        strcpy(buf, "405 Your command is invalid.\r\n");
        //        break;
        //    }
        //}
        //buf_len = strlen(buf);
        //sendto(ld, buf, buf_len, 0, (struct sockaddr*)&remote, sizeof(remote));
        //printf("s server send the msg\n");

    }


    close(info.listen_fd); // �رռ����׽���
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>     /* defines STDIN_FILENO, system calls,etc */
#include <sys/types.h>  /* system data type definitions */
#include <sys/socket.h> /* socket specific definitions */
#include <netinet/in.h> /* INET constants and stuff */
#include <arpa/inet.h>  /* IP address conversion stuff */
#include <netdb.h>      /* gethostbyname */
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#include"StructofServer.h"
#include"FileHandle.h"

int handle_retr(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    FILE* file;
    char file_path[MAXBUF];
    int len;
    char line[MAXBUF];
    int bytes_read;
    if (info->state_flag == 2) {

        strcpy(file_path, msg + 5);
        len = strlen(file_path);
        while (len > 0 && (file_path[len - 1] == '\r' || file_path[len - 1] == '\n'))
             file_path[--len] = 0;  
        
        if (info->binary_flag)
            file = fopen(file_path, "rb");
        else
            file = fopen(file_path, "r");

        if (file == NULL) {
            strcpy(info->buf, "550 File not found.\r\n");
            return 1;
        }

        while ((bytes_read = fread(line, 1, sizeof(line), file)) > 0) {
            printf("%s",line);
            //strcat(info->buf, line);
        }
        // fclose(file);
        // if (info->buf[strlen(info->buf) - 1] != '\n')
        //     strcat(info->buf, "\r\n");
        // strcat(info->buf, "226 Transfer complete.\r\n");
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
    }
    return 0;
}

int handle_mkd(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    char file_path[MAXBUF];
    strcpy(file_path, msg + 5);
    if (info->state_flag == 2) {
        if (strlen(msg) < 4) {
            strcpy(info->buf, "501 Please enter the path.\r\n");
            return 1;
        }
        if(chdir(info->WorkingPlace) != 0){
            strcpy(info->buf, "550 Current path not found.\r\n");
            return 1;
        }
        if(mkdir(file_path, 0)!=0){

            strcpy(info->buf, "550 Fail to create the file.\r\n");
            return 1;
        }
        strcpy(info->buf, "250 Successfully created the file.\r\n");
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_cwd(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    char file_path[MAXBUF];
    strcpy(file_path, msg + 5);
    if (info->state_flag == 2) {
        if (strlen(msg) < 4) {
            strcpy(info->buf, "501 Please enter the path.\r\n");
            return 1;
        }
        if(chdir(file_path) != 0){
            sprintf(info->buf, "550 %s: No such file or directory.\r\n", file_path);
            return 1;
        }else{
            strcpy(info->WorkingPlace, file_path);
            strcpy(info->buf, "250 Okay.\r\n");
        }
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_pwd(const char* msg, struct Serverinfo* info) {
    memset(info->buf, 0, sizeof(info->buf));
    char current_dir[MAXBUF];
    if (info->state_flag == 2) {
        if (strlen(msg) > 4) {
            strcpy(info->buf, "501 Invalid input parameters\r\n");
            return 1;
        }
        if (info->WorkingPlace != NULL) 
            sprintf(info->buf, "257 \"%s\" \r\n", info->WorkingPlace);
        else {
            strcpy(info->buf, "550 Failed to get current directory.\r\n");
            return 1;
        }
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_list(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    char file_path[MAXBUF];
    char command[MAXBUF]="ls -l";
    char line[MAXBUF];
    FILE *file;

    if (info->state_flag == 2) {
        if(chdir(info->WorkingPlace) != 0){
            strcpy(info->buf, "451 Current path not found.\r\n");
            return 1;
        }
        strcpy(file_path, msg + 5);
        if(file_path != NULL)
            strcat(command, file_path);
        if((file = popen(command, "r") == NULL)){
            strcpy(info->buf, "451 Fail to execute the command: popen error.\r\n");
            return 1;
        }
        while(fread(line, 1, sizeof(line), file) > 0){
            strcat(info->buf, line);
        }

        pclose(file);

        if (info->buf[strlen(info->buf) - 1] != '\n')
            strcat(info->buf, "\r\n");
        strcat(info->buf, "226 Transfer complete.\r\n");
        
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

int handle_rmd(const char* msg, struct Serverinfo* info){
    memset(info->buf, 0, sizeof(info->buf));
    char file_path[MAXBUF];
    char command[MAXBUF]="ls -l";
    char line[MAXBUF];
    FILE *file;

    if (info->state_flag == 2) {
        if(chdir(info->WorkingPlace) != 0){
            strcpy(info->buf, "451 Current path not found.\r\n");
            return 1;
        }
        strcpy(file_path, msg + 5);
        if(file_path != NULL)
            strcat(command, file_path);
        if((file = popen(command, "r") == NULL)){
            strcpy(info->buf, "451 Fail to execute the command: popen error.\r\n");
            return 1;
        }
        while(fread(line, 1, sizeof(line), file) > 0){
            strcat(info->buf, line);
        }

        pclose(file);

        if (info->buf[strlen(info->buf) - 1] != '\n')
            strcat(info->buf, "\r\n");
        strcat(info->buf, "226 The directory was successfully removed.\r\n");
        
    }
    else {
        strcpy(info->buf, "530 Please input your username and login first.\r\n");
        return 1;
    }
    return 0;
}

